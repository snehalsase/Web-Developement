using System;

public class OutPatient : Patient
{
    private decimal expense;
    //private String hospitalname;
    private String confirstname;
    private String conlastname;
    //private PhoneNumber conCellPhone;
    public OutPatient(): base()
    {
    }

   // constructor
    public OutPatient(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, decimal expense, String hospitalName, String confirstname, String conlastname, PhoneNumber conCellPhone)
        : base(first, last, married, gender, birthDate, homeAddress, homePhone, cellPhone, hospitalName, confirstname, conlastname, conCellPhone)
   {
       this.expense = expense;
        this.conlastname = conlastname;
        this.confirstname = confirstname;
        //this.ContactCellPhone = conCellPhone;
   } 
   public decimal Expense
   {
      get
      {
          return expense;
      } // end get
      set
      {
          if (value < 0)
              throw new ApplicationException("Salary must not be negative!");
          expense = value; 
      } // end set
   } 
    public override double Coverage
    {
        get
        {

            return (double)Expense - Copay;

        }
    }
    public override double Copay
    {
        get
        {

            return (double)Expense * 0.025;

        }
    }
    
    public override decimal Earnings
   {
       get
       {
           return Expense;
       }
   } 
   public override string Category
   {
       get
       {
           return "Patient";
       }
   } 

} 