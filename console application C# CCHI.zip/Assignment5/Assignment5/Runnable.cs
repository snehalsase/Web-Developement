using System;

public class Runnable
{

    private void Add(ref Patient patient)
    {
        string toReturn;
        bool flag;


        // checking for patient type
        do
        {
            flag = true;
            Console.Write("Patient type: O(ut), R(esident) ? ");
            toReturn = Console.ReadLine();
            if (toReturn.Length < 1)
            {
                flag = false;
                continue;
            }

            if (toReturn.ToUpper() == "O")
            {
                patient = new OutPatient();
                break;
            }
            else if (toReturn.ToUpper() == "R")
            {
                patient = new ResidentPatient();
                break;
            }
            else
            {
                flag = false;
                break;
            }
        }
        while (!flag);

        //checking for first name
        do
        {
            flag = true;
            try
            {
                Console.Write("First Name: ");

                patient.FirstName = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        //checking for last name
        do
        {
            flag = true;
            try
            {
                Console.Write("Last Name: ");
                patient.LastName = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        // checking for gender
        do
        {
            flag = true;
            try
            {
                Console.Write("Gender (M/F): ");
                patient.Gender = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        // Married
        do
        {
            flag = true;
            Console.Write("Married (Y/N)? ");
            toReturn = Console.ReadLine();
            if (toReturn.Length < 1)
            {
                flag = false;
                continue;
            }

            if (toReturn.ToUpper() == "Y")
            {
                patient.Married = true;
                break;
            }
            else if (toReturn.ToUpper() == "N")
            {
                patient.Married = false;
                break;
            }
            else
            {
                flag = false;
                break;
            }
        }
        while (!flag);

        // checking for birth date
        do
        {
            flag = true;
            try
            {
                Console.Write("Birth Date: ");
                patient.BirthDate = DateTime.Parse(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);


        if (patient is OutPatient)
        {
            // weekly salary
            do
            {
                flag = true;
                try
                {
                    Console.Write("Expenses ($): ");
                    ((OutPatient)patient).Expense = decimal.Parse(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);
        }
        else
        {

            do
            {
                flag = true;
                try
                {
                    Console.Write("Expenses ($): ");
                    ((ResidentPatient)patient).Expense = decimal.Parse(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);


        }
        // address
        patient.HomeAddress = new Address();

        // street
        do
        {
            flag = true;
            try
            {
                Console.Write("Street Address: ");
                patient.HomeAddress.Street = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        // city
        do
        {
            flag = true;
            try
            {
                Console.Write("City: ");
                patient.HomeAddress.City = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        // state
        do
        {
            flag = true;
            try
            {
                Console.Write("State: ");
                patient.HomeAddress.State = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        // zip
        do
        {
            flag = true;
            try
            {
                Console.Write("Zip: ");
                patient.HomeAddress.Zip = Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);
        // home phone
        do
        {
            flag = true;
            try
            {
                Console.Write("Home Phone: ");
                patient.HomePhone = new PhoneNumber(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        // cell phone
        do
        {
            flag = true;
            try
            {
                Console.Write("Mobile Phone: ");
                patient.CellPhone = new PhoneNumber(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                flag = false;
            }
        }
        while (!flag);

        if (patient is ResidentPatient)
        {
            do
            {
                flag = true;
                try
                {
                    Console.Write("Hospital Name: ");
                    patient.HospitalName = Console.ReadLine();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);

            // home phone
            do
            {
                flag = true;
                try
                {
                    Console.Write("Hospital Phone: ");
                    patient.HospitalPhone = new PhoneNumber(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);

        }
        else
        {
            do
            {
                flag = true;
                try
                {
                    Console.Write("Contact First Name: ");
                    patient.ContactFirstName = Console.ReadLine();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);

            // last name
            do
            {
                flag = true;
                try
                {
                    Console.Write("Contact Last Name: ");
                    patient.ContactLastName = Console.ReadLine();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);

            do
            {
                flag = true;
                try
                {
                    Console.Write("Contact Phone: ");
                    patient.ContactCellPhone = new PhoneNumber(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    flag = false;
                }
            }
            while (!flag);

        }



    }

    // The Runnable
    private void Run()
    {
        bool quit = false;
        bool valid;
        string choice;
        Patient patient = null;

        Console.WriteLine("Welcome to the CCHI Insurance Coverage System!");

        do
        {

            Console.WriteLine("Enter data about a patient");
            Console.WriteLine();
            Add(ref patient);
            Console.WriteLine();
            Console.WriteLine(patient.ToString());

            Console.WriteLine();
            do
            {
                valid = true;
                Console.Write("Do you want to quit (Y/N)?: ");
                choice = Console.ReadLine().Trim();
                if (choice.Length < 1)
                {
                    valid = false;
                    continue;
                }
                Console.WriteLine();
                switch (choice.ToUpper()[0])
                {
                    case 'N':
                        quit = false;
                        break;
                    case 'Y':
                        quit = true;
                        break;
                    default:
                        valid = false;
                        break;
                }
            } while (!valid);
        }
        while (!quit);

        Console.WriteLine();
        Console.WriteLine("Thank you for using the Payroll System!");
        Console.WriteLine();
    }

    public static void Main(string[] args)
    {
        Runnable toRun = new Runnable();
        toRun.Run();
    }
}
