
using System;

public class PhoneNumber
{
	private string phoneNumberValue = "";
	public override string ToString()
	{
        if (phoneNumberValue == "")
            return "";
        else
            return "("
                    + phoneNumberValue.Substring(0, 3)
                    + ")"
                    + phoneNumberValue.Substring(3, 3)
                    + "-"
                    + phoneNumberValue.Substring(6, 4); 
	}
		
	public PhoneNumber(string phoneNumber)
	{
        if (phoneNumber == "")
            return;
        foreach (char c in phoneNumber)
		{
			if (c >= '0' && c <= '9')
			{
                phoneNumberValue += c;
			}
		}
        if (phoneNumberValue.Length != 10)
            throw new ApplicationException("Improper number of numeric digits for a phone number.");
	}
}