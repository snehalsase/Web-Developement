using System;

public class ResidentPatient : Patient
{
    private decimal expense;
    private String hospitalName;
    public ResidentPatient()
        : base()
    {
    }

    // constructor
    public ResidentPatient(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone,
        decimal expense, String hospitalname , String confirstname, String conlastname, PhoneNumber conCellPhone)
       : base( first, last, married, gender, birthDate, homeAddress, homePhone, cellPhone, hospitalname, confirstname, conlastname,conCellPhone)
   {
      this.Expense = expense;
        this.hospitalName = hospitalname;
   } 

   public decimal Expense
   {
      get
      {
          return expense;
      } // end get
      set
      {
          if (value < 0)
              throw new ApplicationException("Wage must not be negative!");
          expense = value;
      } // end set
   } 
    public override double Copay
    {
        get
        {

            return (double)Expense*0.05;

        }
    }
    public override double Coverage
    {
        get
        {

            return (double)Expense - Copay;

        }
    }
   
    public override decimal Earnings
   {
       get
       {

               return Expense ;
          
       }
   } 

   public override string Category
   {
       get
       {
           return "Resident";
       }
   } 
   
} 

