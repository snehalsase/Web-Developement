using System;

public abstract class Patient
{

    // instance variables to store the data

    // first name
    private string patientFirstName;

    // last name
    private string patientLastName;

    // birth date
    private DateTime patientBirthDate;

    //hospital name for Resident Patient
    private String hospitalName;

    //emergency contact for out patient

    //contact first name
    private String contactFirstname;

    //contact last name
    private String contactLastname;

    //contact phone number
    private PhoneNumber contactPhonePhoner;


    // constructor
    public Patient()
    {

    }
    public Patient(string firstName, string lastName, bool married, string gender, DateTime DOB, Address homeAddress, PhoneNumber homePhone, PhoneNumber mobilePhone, String hospitalName
        , String contactfirstname, String contactlastname, PhoneNumber contactPhone)
    {
        this.FirstName = firstName;
        this.LastName = lastName;
        this.Married = married;
        this.Gender = gender;
        this.BirthDate = DOB;
        this.HomeAddress = homeAddress;
        this.HomePhone = homePhone;
        this.CellPhone = mobilePhone;
        this.hospitalName = hospitalName;
        this.contactFirstname = contactfirstname;
        this.contactLastname = contactlastname;
        this.contactPhonePhoner = contactPhone;
    }

    ////getters and setters for first name
    public string FirstName
    {
        get
        {
            if (patientFirstName == null) return null;
            if (patientFirstName.Length == 1) return patientFirstName.ToUpper();
            return patientFirstName.Substring(0, 1).ToUpper() + patientFirstName.Substring(1).ToLower();
        }

        set
        {
            value = value.ToLower();
            if (value.Length < 1)
                throw new ArgumentException("First name is empty..");

            // check for only letters
            foreach (char c in value)
                if (c < 'a' || c > 'z')
                    throw new ArgumentException("First name should have letters only..");
            patientFirstName = value;
        }
    }


    ////getters and setters for last name
    public string LastName
    {
        get
        {
            if (patientLastName == null) return null;
            if (patientLastName.Length == 1) return patientLastName.ToUpper();
            return patientLastName.Substring(0, 1).ToUpper() + patientLastName.Substring(1).ToLower();
        }
        set
        {
            value = value.ToLower();
            if (value.Length < 1)
                throw new ArgumentException("Last name is empty..");

            // check for only letters
            foreach (char c in value)
                if (c < 'a' || c > 'z')
                    throw new ArgumentException("Last name should have letters only..");
            patientLastName = value;
        }
    }

    ////getters and setters for contact first name 
    public string ConFirstName
    {
        get
        {
            if (contactFirstname == null) return null;
            if (contactFirstname.Length == 1) return contactFirstname.ToUpper();
            return contactFirstname.Substring(0, 1).ToUpper() + contactFirstname.Substring(1).ToLower();
        }
        set
        {
            value = value.ToLower();
            if (value.Length < 1)
                throw new ArgumentException("Contact First name is empty..");

            // check for only letters
            foreach (char c in value)
                if (c < 'a' || c > 'z')
                    throw new ArgumentException("Contact First name should have letters only..");
            contactFirstname = value;
        }
    }

    ////getters and setters for contact first name
    public string ConLastName
    {
        get
        {
            if (contactLastname == null) return null;
            if (contactLastname.Length == 1) return contactLastname.ToUpper();
            return contactLastname.Substring(0, 1).ToUpper() + contactLastname.Substring(1).ToLower();
        }
        set
        {
            value = value.ToLower();
            if (value.Length < 1)
                throw new ArgumentException("Contact Last name is empty..");

            // check for only letters
            foreach (char c in value)
                if (c < 'a' || c > 'z')
                    throw new ArgumentException("Contact Last name should have letters only..");
            contactLastname = value;
        }
    }

    //// only getter for full name
    public string Name
    {
        get
        {
            return LastName + ", " + FirstName;
        }
    }

    //// getters and setters for married 
    public bool Married { get; set; }

    // getters and setters for hospital name for resident patient
    public string HospitalName
    {
        get
        {
            if (hospitalName == null) return " ";
            return "  Hospital : " + hospitalName;
        }
        set
        {
            hospitalName = value;
        }
    }

    // 
    public string ContactFirstName
    {
        get
        {
            if (ConFirstName == null)
                return " ";
            else
                return ConFirstName;
        }
        set
        {
            ConFirstName = value;
        }
    }

    public string ContactLastName
    {
        get
        {
            if (ConLastName == null)
                return " ";
            else
                return "Contact : " + ConLastName + ",";
        }
        set
        {
            ConLastName = value;
        }
    }
    public string MaritalStatus
    {
        get
        {
            if (Married)
                return "Married";
            else
                return "Single";
        }
    }

    //  whether employee is male or not
    public bool IsMale { get; set; }

    // whether employee is female or not
    public bool IsFemale
    {
        get
        {
            return !IsMale;
        }
        set
        {
            IsMale = !value;
        }
    }

    //determine gender based on male and female
    public string Gender
    {
        get
        {
            if (IsMale)
                return "Male";
            else
                return "Female";
        }
        set
        {
            if (value == "M")
                IsMale = true;
            else if (value == "F")
                IsMale = false;
            else
                throw new ArgumentException("Gender should be Male or Female!");
        }
    }

    //title according to gender
    public string Title
    {
        get
        {
            if (IsMale)
                return "Mr.";
            else
                return "Ms.";
        }
    }

    //full name along with title
    public string TitleName
    {
        get
        {
            return Title + " " + Name;
        } // end get
    }

    //Date of Birth of patient
    public DateTime BirthDate
    {
        get
        {
            return patientBirthDate;
        }
        set
        {
            if (value > DateTime.Now)
            {
                throw new ArgumentException("Employee birth date must be prior to today!");
            }
            patientBirthDate = value;
        }
    }

    //calculating Age from the date of birth
    public int Age
    {
        get
        {
            DateTime thisYearBirthDate = new DateTime(DateTime.Now.Year, BirthDate.Month, BirthDate.Day);
            if (thisYearBirthDate <= DateTime.Now) return (DateTime.Now.Year - BirthDate.Year);
            return (DateTime.Now.Year - BirthDate.Year - 1);
        }
    }

    public Address HomeAddress { get; set; }

    public PhoneNumber HomePhone { get; set; }

    public PhoneNumber HospitalPhone { get; set; }
    public virtual double Copay { get; set; }
    public PhoneNumber CellPhone { get; set; }

    public PhoneNumber ContactCellPhone { get; set; }
    public virtual double Coverage { get; set; }
    public override string ToString()
    {
        return TitleName + "\t" + Category + "," + MaritalStatus + " " + "Age:" + Age + ","
        + "Expense: " + Earnings.ToString("C") + "," + "Copay: " + Copay.ToString("C") + " "
        + " Coverage " + Coverage.ToString("C") + "\t" + HomeAddress + HomePhone + CellPhone + HospitalName + HospitalPhone
        + ContactLastName + ContactFirstName + ContactCellPhone;
    }
    public virtual string Category
    {
        get
        {
            return "Patient";
        }
    }
    public abstract decimal Earnings
    {
        get;
    }


}