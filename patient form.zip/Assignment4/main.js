let id=document.getElementById("id")
let form=document.getElementById("form")
let first=document.getElementById("first")
let last=document.getElementById("last")
let total=document.getElementById("total")
let out=document.getElementById("out")
let resident=document.getElementById("resident")
let save=document.getElementById("save")
let clear=document.getElementById("clear")
let list=document.getElementById("list")
let edit=document.getElementById("edit")
let toDelete=document.getElementById("toDelete")
let patients=localStorage.getItem('patients')
? JSON.parse(localStorage.getItem('patients'))
: []

localStorage.setItem('patients', JSON.stringify(patients))
const data = JSON.parse(localStorage.getItem('patients'))

const liMaker = (patient) => {
    const li = document.createElement('li')
    li.id=patient.id
    li.textContent = `${patient.first} ${patient.last} Type:${patient.type} Exp:${patient.totalExpenses} Cov:${patient.coveredExpenses} `
    const edit = document.createElement('button')
    const toDelete = document.createElement('button')
    edit.textContent="Edit"
    toDelete.textContent="Delete"
    edit.id="edit"
    toDelete.id="toDelete"
    li.appendChild(edit)
    li.appendChild(toDelete)
    list.appendChild(li)
  }

form.addEventListener('submit',(e)=>{
    e.preventDefault()
    if(id.value==="" || first.value==="" ||last.value==="" || total.value==="")return
    let idAlreadyExists=false
    patients.forEach(patient=>{
        if(patient.id===id.value) idAlreadyExists=true
    })
    if(idAlreadyExists) {
        id.value=""
        first.value=""
        last.value=""
        total.value=""
        return
    }
    let type=out.checked?"O":"R"
    let totalExpenses=total.value
    let copayAmount=type==="O"?(2.5*totalExpenses/100):(5*totalExpenses/100)
    let patient={
        id:id.value,
        first:first.value,
        last: last.value,
        type: type,
        totalExpenses:totalExpenses,
        coveredExpenses:totalExpenses-copayAmount
    }
    patients.push(patient)
    localStorage.setItem('patients', JSON.stringify(patients))
    liMaker(patient)
    id.value=""
    first.value=""
    last.value=""
    total.value=""
})

data.forEach(element => {
  liMaker(element)  
})

clear.addEventListener('click', ()=> {
    localStorage.clear()
    patients=[]
    while (list.firstChild) {
      list.removeChild(list.firstChild)
    }
  })

document.addEventListener('click',(e)=>{
    if(e.target && e.target.id== 'toDelete'){
        remove(e)
     }
 })

document.addEventListener('click',(e)=>{
    if(e.target && e.target.id== 'edit'){
        let pid=e.target.parentNode.id
        let temp
        patients.forEach((patient)=>{
            if(patient.id===pid) temp=patient
        })
        id.value=temp.id
        first.value=temp.first
        last.value=temp.last
        total.value=temp.totalExpenses
        if(temp.type==="O") out.checked=true
        else resident.checked=true
        remove(e)
     }
 })

const remove= (e)=>{
    let id=e.target.parentNode.id
    let temp = patients.filter(x => x.id != id)
    patients=temp;
    localStorage.setItem('patients', JSON.stringify(patients))
    list.removeChild(e.target.parentNode)
 }