let inputExpenses = prompt("Enter Total expenses ($)", 0);

while (!checkifNumber(inputExpenses)) {
    inputExpenses = prompt("Enter Total expenses ($)", 0);
    console.log(Number.parseInt(inputExpenses, 10));
}
let inputType = prompt("Type of patient (O/R)", null);
inputType = inputType.toUpperCase();
while (inputType !== 'O' && inputType !== 'R') {
    inputType = prompt("Type of patient (O/R)", null);
    inputType = inputType.toUpperCase();
    console.log(inputType);
}

function checkifNumber(s) {
    for (var i = 0; i < s.length; i++) {
        if (s[i] >= '0' && s[i] <= '9') {

        }
        else {
            return false;
        }

    }
    return true;
}

newFunction();


function newFunction() {
    document.addEventListener('DOMContentLoaded', () => {
        let copayRate;
        if (inputType === 'O') {
            copayRate = 2.5;
            inputType = "Out Patient";
        }
        else {
            copayRate = 5;
            inputType = "Resident Patient";
        }
        const copayAmount = (copayRate / 100) * inputExpenses;
        //var test = toString(copayAmount);
        const InsuranceCoverage = inputExpenses - copayAmount;


        const inputElement = document.getElementById("expenses");
        inputElement.innerHTML = "$" +inputExpenses;

        const inputPatient = document.getElementById("patient");
        inputPatient.innerHTML = inputType;


        const inputRate = document.getElementById("rate");
        inputRate.innerHTML = copayRate + "%";

        const inputAmount = document.getElementById("amount");
        inputAmount.innerHTML = "$" + copayAmount;

        const inputCoverage = document.getElementById("coverage");
        inputCoverage.innerHTML = "$" +InsuranceCoverage;
    });
}
