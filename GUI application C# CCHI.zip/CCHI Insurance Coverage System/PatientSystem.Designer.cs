﻿namespace CCHISystem
{
        partial class PatientSystem
        {
                /// <summary>
                /// Required designer variable.
                /// </summary>
                private System.ComponentModel.IContainer components = null;

                /// <summary>
                /// Clean up any resources being used.
                /// </summary>
                /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
                protected override void Dispose(bool disposing)
                {
                        if (disposing && (components != null))
                        {
                                components.Dispose();
                        }
                        base.Dispose(disposing);
                }

                #region Windows Form Designer generated code

                /// <summary>
                /// Required method for Designer support - do not modify
                /// the contents of this method with the code editor.
                /// </summary>
                private void InitializeComponent()
                {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.firstNameInput = new System.Windows.Forms.TextBox();
            this.lastNameInput = new System.Windows.Forms.TextBox();
            this.patientTypeInput = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.TypeLabel1 = new System.Windows.Forms.Label();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.maleRadioButton = new System.Windows.Forms.RadioButton();
            this.femaleRadioButton = new System.Windows.Forms.RadioButton();
            this.marriedCheckbox = new System.Windows.Forms.CheckBox();
            this.expensesLabel = new System.Windows.Forms.Label();
            this.expensesInput = new System.Windows.Forms.TextBox();
            this.birthDateLabel = new System.Windows.Forms.Label();
            this.dateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.ageLabel = new System.Windows.Forms.Label();
            this.ageInput = new System.Windows.Forms.TextBox();
            this.copayWithheldPercenatgeInput = new System.Windows.Forms.TextBox();
            this.copayPercentLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.cityInput = new System.Windows.Forms.TextBox();
            this.pincodeInput = new System.Windows.Forms.TextBox();
            this.copayDollerLabel = new System.Windows.Forms.Label();
            this.copayWithheld = new System.Windows.Forms.TextBox();
            this.insuranceInput = new System.Windows.Forms.TextBox();
            this.insuranceLabel = new System.Windows.Forms.Label();
            this.homePhoneLabel = new System.Windows.Forms.Label();
            this.homePhoneInput = new System.Windows.Forms.TextBox();
            this.mobilePhoneInput = new System.Windows.Forms.TextBox();
            this.mobilePhoneLabel = new System.Windows.Forms.Label();
            this.redOutPatient = new System.Windows.Forms.RadioButton();
            this.residentRadioButton = new System.Windows.Forms.RadioButton();
            this.conFirstNameInput = new System.Windows.Forms.TextBox();
            this.conFirstNameLabel = new System.Windows.Forms.Label();
            this.conLastNameLabel = new System.Windows.Forms.Label();
            this.contactLastName = new System.Windows.Forms.TextBox();
            this.contactPhone = new System.Windows.Forms.TextBox();
            this.conPhoneLabel = new System.Windows.Forms.Label();
            this.hospitalNameLabel = new System.Windows.Forms.Label();
            this.hospitalInput = new System.Windows.Forms.TextBox();
            this.hospitalPhoneInput = new System.Windows.Forms.TextBox();
            this.hospitalPhoneLabel = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.updateButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.patientListBox = new System.Windows.Forms.ListBox();
            this.genderGroupBox = new System.Windows.Forms.GroupBox();
            this.patientTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.comState = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pageSetupStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abroutPayrollSystemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.genderGroupBox.SuspendLayout();
            this.patientTypeGroupBox.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameLabel.Location = new System.Drawing.Point(28, 42);
            this.firstNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(84, 16);
            this.firstNameLabel.TabIndex = 0;
            this.firstNameLabel.Text = "First Name :";
            // 
            // firstNameInput
            // 
            this.firstNameInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameInput.Location = new System.Drawing.Point(116, 38);
            this.firstNameInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.firstNameInput.Name = "firstNameInput";
            this.firstNameInput.Size = new System.Drawing.Size(92, 22);
            this.firstNameInput.TabIndex = 1;
            // 
            // lastNameInput
            // 
            this.lastNameInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameInput.Location = new System.Drawing.Point(305, 41);
            this.lastNameInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lastNameInput.Name = "lastNameInput";
            this.lastNameInput.Size = new System.Drawing.Size(106, 22);
            this.lastNameInput.TabIndex = 2;
            // 
            // patientTypeInput
            // 
            this.patientTypeInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientTypeInput.Location = new System.Drawing.Point(542, 38);
            this.patientTypeInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.patientTypeInput.Name = "patientTypeInput";
            this.patientTypeInput.ReadOnly = true;
            this.patientTypeInput.Size = new System.Drawing.Size(76, 22);
            this.patientTypeInput.TabIndex = 3;
            this.patientTypeInput.TabStop = false;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLabel.Location = new System.Drawing.Point(218, 42);
            this.lastNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(83, 16);
            this.lastNameLabel.TabIndex = 4;
            this.lastNameLabel.Text = "Last Name :";
            // 
            // TypeLabel1
            // 
            this.TypeLabel1.AutoSize = true;
            this.TypeLabel1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeLabel1.Location = new System.Drawing.Point(479, 42);
            this.TypeLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TypeLabel1.Name = "TypeLabel1";
            this.TypeLabel1.Size = new System.Drawing.Size(46, 16);
            this.TypeLabel1.TabIndex = 5;
            this.TypeLabel1.Text = "Type :";
            this.TypeLabel1.Click += new System.EventHandler(this.label3_Click);
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderLabel.Location = new System.Drawing.Point(1, 17);
            this.GenderLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(63, 16);
            this.GenderLabel.TabIndex = 6;
            this.GenderLabel.Text = "Gender :";
            // 
            // maleRadioButton
            // 
            this.maleRadioButton.AutoSize = true;
            this.maleRadioButton.Location = new System.Drawing.Point(66, 17);
            this.maleRadioButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.maleRadioButton.Name = "maleRadioButton";
            this.maleRadioButton.Size = new System.Drawing.Size(48, 17);
            this.maleRadioButton.TabIndex = 7;
            this.maleRadioButton.TabStop = true;
            this.maleRadioButton.Text = "Male";
            this.maleRadioButton.UseVisualStyleBackColor = true;
            // 
            // femaleRadioButton
            // 
            this.femaleRadioButton.AutoSize = true;
            this.femaleRadioButton.Location = new System.Drawing.Point(118, 17);
            this.femaleRadioButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.femaleRadioButton.Name = "femaleRadioButton";
            this.femaleRadioButton.Size = new System.Drawing.Size(59, 17);
            this.femaleRadioButton.TabIndex = 8;
            this.femaleRadioButton.TabStop = true;
            this.femaleRadioButton.Text = "Female";
            this.femaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // marriedCheckbox
            // 
            this.marriedCheckbox.AutoSize = true;
            this.marriedCheckbox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marriedCheckbox.Location = new System.Drawing.Point(220, 78);
            this.marriedCheckbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.marriedCheckbox.Name = "marriedCheckbox";
            this.marriedCheckbox.Size = new System.Drawing.Size(76, 20);
            this.marriedCheckbox.TabIndex = 9;
            this.marriedCheckbox.Text = "Married";
            this.marriedCheckbox.UseVisualStyleBackColor = true;
            // 
            // expensesLabel
            // 
            this.expensesLabel.AutoSize = true;
            this.expensesLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expensesLabel.Location = new System.Drawing.Point(461, 77);
            this.expensesLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.expensesLabel.Name = "expensesLabel";
            this.expensesLabel.Size = new System.Drawing.Size(76, 16);
            this.expensesLabel.TabIndex = 10;
            this.expensesLabel.Text = "Expenses :";
            // 
            // expensesInput
            // 
            this.expensesInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expensesInput.Location = new System.Drawing.Point(542, 76);
            this.expensesInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.expensesInput.Name = "expensesInput";
            this.expensesInput.Size = new System.Drawing.Size(76, 22);
            this.expensesInput.TabIndex = 11;
            // 
            // birthDateLabel
            // 
            this.birthDateLabel.AutoSize = true;
            this.birthDateLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.birthDateLabel.Location = new System.Drawing.Point(23, 108);
            this.birthDateLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.birthDateLabel.Name = "birthDateLabel";
            this.birthDateLabel.Size = new System.Drawing.Size(75, 16);
            this.birthDateLabel.TabIndex = 12;
            this.birthDateLabel.Text = "Birth Date:";
            // 
            // dateOfBirth
            // 
            this.dateOfBirth.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateOfBirth.Location = new System.Drawing.Point(102, 108);
            this.dateOfBirth.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateOfBirth.Name = "dateOfBirth";
            this.dateOfBirth.Size = new System.Drawing.Size(151, 22);
            this.dateOfBirth.TabIndex = 13;
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageLabel.Location = new System.Drawing.Point(272, 110);
            this.ageLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(41, 16);
            this.ageLabel.TabIndex = 14;
            this.ageLabel.Text = "Age: ";
            // 
            // ageInput
            // 
            this.ageInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageInput.Location = new System.Drawing.Point(317, 108);
            this.ageInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ageInput.Name = "ageInput";
            this.ageInput.ReadOnly = true;
            this.ageInput.Size = new System.Drawing.Size(76, 22);
            this.ageInput.TabIndex = 15;
            // 
            // copayWithheldPercenatgeInput
            // 
            this.copayWithheldPercenatgeInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copayWithheldPercenatgeInput.Location = new System.Drawing.Point(542, 129);
            this.copayWithheldPercenatgeInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.copayWithheldPercenatgeInput.Name = "copayWithheldPercenatgeInput";
            this.copayWithheldPercenatgeInput.ReadOnly = true;
            this.copayWithheldPercenatgeInput.Size = new System.Drawing.Size(76, 22);
            this.copayWithheldPercenatgeInput.TabIndex = 16;
            // 
            // copayPercentLabel
            // 
            this.copayPercentLabel.AutoSize = true;
            this.copayPercentLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copayPercentLabel.Location = new System.Drawing.Point(464, 132);
            this.copayPercentLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.copayPercentLabel.Name = "copayPercentLabel";
            this.copayPercentLabel.Size = new System.Drawing.Size(74, 16);
            this.copayPercentLabel.TabIndex = 17;
            this.copayPercentLabel.Text = "Copay (%):";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLabel.Location = new System.Drawing.Point(28, 153);
            this.addressLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(66, 16);
            this.addressLabel.TabIndex = 18;
            this.addressLabel.Text = "Address :";
            // 
            // txtStreet
            // 
            this.txtStreet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStreet.Location = new System.Drawing.Point(92, 150);
            this.txtStreet.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(327, 22);
            this.txtStreet.TabIndex = 19;
            // 
            // cityInput
            // 
            this.cityInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityInput.Location = new System.Drawing.Point(92, 173);
            this.cityInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cityInput.Name = "cityInput";
            this.cityInput.Size = new System.Drawing.Size(151, 22);
            this.cityInput.TabIndex = 20;
            // 
            // pincodeInput
            // 
            this.pincodeInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pincodeInput.Location = new System.Drawing.Point(370, 173);
            this.pincodeInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pincodeInput.Name = "pincodeInput";
            this.pincodeInput.Size = new System.Drawing.Size(49, 22);
            this.pincodeInput.TabIndex = 22;
            // 
            // copayDollerLabel
            // 
            this.copayDollerLabel.AutoSize = true;
            this.copayDollerLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copayDollerLabel.Location = new System.Drawing.Point(464, 167);
            this.copayDollerLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.copayDollerLabel.Name = "copayDollerLabel";
            this.copayDollerLabel.Size = new System.Drawing.Size(71, 16);
            this.copayDollerLabel.TabIndex = 23;
            this.copayDollerLabel.Text = "Copay ($):";
            // 
            // copayWithheld
            // 
            this.copayWithheld.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copayWithheld.Location = new System.Drawing.Point(542, 167);
            this.copayWithheld.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.copayWithheld.Name = "copayWithheld";
            this.copayWithheld.ReadOnly = true;
            this.copayWithheld.Size = new System.Drawing.Size(76, 22);
            this.copayWithheld.TabIndex = 24;
            // 
            // insuranceInput
            // 
            this.insuranceInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insuranceInput.Location = new System.Drawing.Point(542, 202);
            this.insuranceInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.insuranceInput.Name = "insuranceInput";
            this.insuranceInput.ReadOnly = true;
            this.insuranceInput.Size = new System.Drawing.Size(76, 22);
            this.insuranceInput.TabIndex = 25;
            // 
            // insuranceLabel
            // 
            this.insuranceLabel.AutoSize = true;
            this.insuranceLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insuranceLabel.Location = new System.Drawing.Point(464, 206);
            this.insuranceLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.insuranceLabel.Name = "insuranceLabel";
            this.insuranceLabel.Size = new System.Drawing.Size(74, 16);
            this.insuranceLabel.TabIndex = 26;
            this.insuranceLabel.Text = "Insurance:";
            // 
            // homePhoneLabel
            // 
            this.homePhoneLabel.AutoSize = true;
            this.homePhoneLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homePhoneLabel.Location = new System.Drawing.Point(28, 218);
            this.homePhoneLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.homePhoneLabel.Name = "homePhoneLabel";
            this.homePhoneLabel.Size = new System.Drawing.Size(94, 16);
            this.homePhoneLabel.TabIndex = 27;
            this.homePhoneLabel.Text = "Home Phone:";
            // 
            // homePhoneInput
            // 
            this.homePhoneInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homePhoneInput.Location = new System.Drawing.Point(119, 216);
            this.homePhoneInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.homePhoneInput.Name = "homePhoneInput";
            this.homePhoneInput.Size = new System.Drawing.Size(97, 22);
            this.homePhoneInput.TabIndex = 28;
            // 
            // mobilePhoneInput
            // 
            this.mobilePhoneInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobilePhoneInput.Location = new System.Drawing.Point(347, 216);
            this.mobilePhoneInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mobilePhoneInput.Name = "mobilePhoneInput";
            this.mobilePhoneInput.Size = new System.Drawing.Size(113, 22);
            this.mobilePhoneInput.TabIndex = 29;
            // 
            // mobilePhoneLabel
            // 
            this.mobilePhoneLabel.AutoSize = true;
            this.mobilePhoneLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobilePhoneLabel.Location = new System.Drawing.Point(235, 219);
            this.mobilePhoneLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mobilePhoneLabel.Name = "mobilePhoneLabel";
            this.mobilePhoneLabel.Size = new System.Drawing.Size(108, 16);
            this.mobilePhoneLabel.TabIndex = 30;
            this.mobilePhoneLabel.Text = "Mobile Phone : ";
            // 
            // redOutPatient
            // 
            this.redOutPatient.AutoSize = true;
            this.redOutPatient.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.redOutPatient.Location = new System.Drawing.Point(8, 28);
            this.redOutPatient.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.redOutPatient.Name = "redOutPatient";
            this.redOutPatient.Size = new System.Drawing.Size(48, 20);
            this.redOutPatient.TabIndex = 31;
            this.redOutPatient.TabStop = true;
            this.redOutPatient.Text = "Out";
            this.redOutPatient.UseVisualStyleBackColor = true;
            this.redOutPatient.CheckedChanged += new System.EventHandler(this.redOutPatient_CheckedChanged);
            // 
            // residentRadioButton
            // 
            this.residentRadioButton.AutoSize = true;
            this.residentRadioButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.residentRadioButton.Location = new System.Drawing.Point(8, 99);
            this.residentRadioButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.residentRadioButton.Name = "residentRadioButton";
            this.residentRadioButton.Size = new System.Drawing.Size(81, 20);
            this.residentRadioButton.TabIndex = 32;
            this.residentRadioButton.TabStop = true;
            this.residentRadioButton.Text = "Resident";
            this.residentRadioButton.UseVisualStyleBackColor = true;
            this.residentRadioButton.CheckedChanged += new System.EventHandler(this.residentRadioButton_CheckedChanged);
            // 
            // conFirstNameInput
            // 
            this.conFirstNameInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conFirstNameInput.Location = new System.Drawing.Point(256, 266);
            this.conFirstNameInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.conFirstNameInput.Name = "conFirstNameInput";
            this.conFirstNameInput.Size = new System.Drawing.Size(104, 22);
            this.conFirstNameInput.TabIndex = 33;
            // 
            // conFirstNameLabel
            // 
            this.conFirstNameLabel.AutoSize = true;
            this.conFirstNameLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conFirstNameLabel.Location = new System.Drawing.Point(116, 267);
            this.conFirstNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.conFirstNameLabel.Name = "conFirstNameLabel";
            this.conFirstNameLabel.Size = new System.Drawing.Size(136, 16);
            this.conFirstNameLabel.TabIndex = 34;
            this.conFirstNameLabel.Text = "Contact First Name :";
            // 
            // conLastNameLabel
            // 
            this.conLastNameLabel.AutoSize = true;
            this.conLastNameLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conLastNameLabel.Location = new System.Drawing.Point(367, 272);
            this.conLastNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.conLastNameLabel.Name = "conLastNameLabel";
            this.conLastNameLabel.Size = new System.Drawing.Size(135, 16);
            this.conLastNameLabel.TabIndex = 35;
            this.conLastNameLabel.Text = "Contact Last Name :";
            // 
            // contactLastName
            // 
            this.contactLastName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactLastName.Location = new System.Drawing.Point(506, 268);
            this.contactLastName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contactLastName.Name = "contactLastName";
            this.contactLastName.Size = new System.Drawing.Size(132, 22);
            this.contactLastName.TabIndex = 36;
            // 
            // contactPhone
            // 
            this.contactPhone.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactPhone.Location = new System.Drawing.Point(249, 292);
            this.contactPhone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contactPhone.Name = "contactPhone";
            this.contactPhone.Size = new System.Drawing.Size(104, 22);
            this.contactPhone.TabIndex = 37;
            // 
            // conPhoneLabel
            // 
            this.conPhoneLabel.AutoSize = true;
            this.conPhoneLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conPhoneLabel.Location = new System.Drawing.Point(136, 296);
            this.conPhoneLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.conPhoneLabel.Name = "conPhoneLabel";
            this.conPhoneLabel.Size = new System.Drawing.Size(109, 16);
            this.conPhoneLabel.TabIndex = 38;
            this.conPhoneLabel.Text = "Contact Phone :";
            // 
            // hospitalNameLabel
            // 
            this.hospitalNameLabel.AutoSize = true;
            this.hospitalNameLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitalNameLabel.Location = new System.Drawing.Point(136, 338);
            this.hospitalNameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.hospitalNameLabel.Name = "hospitalNameLabel";
            this.hospitalNameLabel.Size = new System.Drawing.Size(108, 16);
            this.hospitalNameLabel.TabIndex = 39;
            this.hospitalNameLabel.Text = "Hospital Name :";
            // 
            // hospitalInput
            // 
            this.hospitalInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitalInput.Location = new System.Drawing.Point(247, 335);
            this.hospitalInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.hospitalInput.Name = "hospitalInput";
            this.hospitalInput.Size = new System.Drawing.Size(144, 22);
            this.hospitalInput.TabIndex = 40;
            // 
            // hospitalPhoneInput
            // 
            this.hospitalPhoneInput.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitalPhoneInput.Location = new System.Drawing.Point(502, 332);
            this.hospitalPhoneInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.hospitalPhoneInput.Name = "hospitalPhoneInput";
            this.hospitalPhoneInput.Size = new System.Drawing.Size(132, 22);
            this.hospitalPhoneInput.TabIndex = 41;
            // 
            // hospitalPhoneLabel
            // 
            this.hospitalPhoneLabel.AutoSize = true;
            this.hospitalPhoneLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hospitalPhoneLabel.Location = new System.Drawing.Point(390, 335);
            this.hospitalPhoneLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.hospitalPhoneLabel.Name = "hospitalPhoneLabel";
            this.hospitalPhoneLabel.Size = new System.Drawing.Size(112, 16);
            this.hospitalPhoneLabel.TabIndex = 42;
            this.hospitalPhoneLabel.Text = "Hospital Phone :";
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.Location = new System.Drawing.Point(32, 375);
            this.addButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(92, 28);
            this.addButton.TabIndex = 43;
            this.addButton.Text = "&Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateButton.Location = new System.Drawing.Point(195, 375);
            this.updateButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(98, 28);
            this.updateButton.TabIndex = 44;
            this.updateButton.Text = "&Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteButton.Location = new System.Drawing.Point(359, 375);
            this.deleteButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(84, 28);
            this.deleteButton.TabIndex = 45;
            this.deleteButton.Text = "&Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(512, 375);
            this.clearButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(96, 28);
            this.clearButton.TabIndex = 46;
            this.clearButton.Text = "&Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // patientListBox
            // 
            this.patientListBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientListBox.FormattingEnabled = true;
            this.patientListBox.ItemHeight = 16;
            this.patientListBox.Location = new System.Drawing.Point(4, 419);
            this.patientListBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.patientListBox.Name = "patientListBox";
            this.patientListBox.Size = new System.Drawing.Size(632, 68);
            this.patientListBox.TabIndex = 47;
            this.patientListBox.SelectedIndexChanged += new System.EventHandler(this.lstPatient_SelectedIndexChanged);
            // 
            // genderGroupBox
            // 
            this.genderGroupBox.Controls.Add(this.GenderLabel);
            this.genderGroupBox.Controls.Add(this.maleRadioButton);
            this.genderGroupBox.Controls.Add(this.femaleRadioButton);
            this.genderGroupBox.Location = new System.Drawing.Point(26, 62);
            this.genderGroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.genderGroupBox.Name = "genderGroupBox";
            this.genderGroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.genderGroupBox.Size = new System.Drawing.Size(190, 39);
            this.genderGroupBox.TabIndex = 48;
            this.genderGroupBox.TabStop = false;
            // 
            // patientTypeGroupBox
            // 
            this.patientTypeGroupBox.Controls.Add(this.redOutPatient);
            this.patientTypeGroupBox.Controls.Add(this.residentRadioButton);
            this.patientTypeGroupBox.Location = new System.Drawing.Point(30, 239);
            this.patientTypeGroupBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.patientTypeGroupBox.Name = "patientTypeGroupBox";
            this.patientTypeGroupBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.patientTypeGroupBox.Size = new System.Drawing.Size(82, 132);
            this.patientTypeGroupBox.TabIndex = 49;
            this.patientTypeGroupBox.TabStop = false;
            // 
            // comState
            // 
            this.comState.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comState.FormattingEnabled = true;
            this.comState.Location = new System.Drawing.Point(247, 173);
            this.comState.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comState.Name = "comState";
            this.comState.Size = new System.Drawing.Size(120, 24);
            this.comState.TabIndex = 50;
            this.comState.SelectedIndexChanged += new System.EventHandler(this.comState_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(638, 24);
            this.menuStrip1.TabIndex = 51;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripSeparator3,
            this.saveToolStripMenuItem,
            this.toolStripSeparator2,
            this.pageSetupStripMenuItem,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(140, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.saveToolStripMenuItem.Text = "&Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(140, 6);
            // 
            // pageSetupStripMenuItem
            // 
            this.pageSetupStripMenuItem.Name = "pageSetupStripMenuItem";
            this.pageSetupStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.pageSetupStripMenuItem.Text = "Page Setup";
            this.pageSetupStripMenuItem.Click += new System.EventHandler(this.pageSetupStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(140, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abroutPayrollSystemToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.editToolStripMenuItem.Text = "Help";
            // 
            // abroutPayrollSystemToolStripMenuItem
            // 
            this.abroutPayrollSystemToolStripMenuItem.Name = "abroutPayrollSystemToolStripMenuItem";
            this.abroutPayrollSystemToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.abroutPayrollSystemToolStripMenuItem.Text = "&About Patient System";
            this.abroutPayrollSystemToolStripMenuItem.Click += new System.EventHandler(this.abroutPayrollSystemToolStripMenuItem_Click);
            // 
            // PatientSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 497);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.comState);
            this.Controls.Add(this.patientTypeGroupBox);
            this.Controls.Add(this.genderGroupBox);
            this.Controls.Add(this.patientListBox);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.hospitalPhoneLabel);
            this.Controls.Add(this.hospitalPhoneInput);
            this.Controls.Add(this.hospitalInput);
            this.Controls.Add(this.hospitalNameLabel);
            this.Controls.Add(this.conPhoneLabel);
            this.Controls.Add(this.contactPhone);
            this.Controls.Add(this.contactLastName);
            this.Controls.Add(this.conLastNameLabel);
            this.Controls.Add(this.conFirstNameLabel);
            this.Controls.Add(this.conFirstNameInput);
            this.Controls.Add(this.mobilePhoneLabel);
            this.Controls.Add(this.mobilePhoneInput);
            this.Controls.Add(this.homePhoneInput);
            this.Controls.Add(this.homePhoneLabel);
            this.Controls.Add(this.insuranceLabel);
            this.Controls.Add(this.insuranceInput);
            this.Controls.Add(this.copayWithheld);
            this.Controls.Add(this.copayDollerLabel);
            this.Controls.Add(this.pincodeInput);
            this.Controls.Add(this.cityInput);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.copayPercentLabel);
            this.Controls.Add(this.copayWithheldPercenatgeInput);
            this.Controls.Add(this.ageInput);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.dateOfBirth);
            this.Controls.Add(this.birthDateLabel);
            this.Controls.Add(this.expensesInput);
            this.Controls.Add(this.expensesLabel);
            this.Controls.Add(this.marriedCheckbox);
            this.Controls.Add(this.TypeLabel1);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.patientTypeInput);
            this.Controls.Add(this.lastNameInput);
            this.Controls.Add(this.firstNameInput);
            this.Controls.Add(this.firstNameLabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "PatientSystem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CCHI Insurance Coverage System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PatientSystemForm_FormClosing);
            this.Load += new System.EventHandler(this.PatientSystem_Load);
            this.genderGroupBox.ResumeLayout(false);
            this.genderGroupBox.PerformLayout();
            this.patientTypeGroupBox.ResumeLayout(false);
            this.patientTypeGroupBox.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

                }

                #endregion

                private System.Windows.Forms.Label firstNameLabel;
                private System.Windows.Forms.TextBox firstNameInput;
                private System.Windows.Forms.TextBox lastNameInput;
                private System.Windows.Forms.TextBox patientTypeInput;
                private System.Windows.Forms.Label lastNameLabel;
                private System.Windows.Forms.Label TypeLabel1;
                private System.Windows.Forms.Label GenderLabel;
                private System.Windows.Forms.RadioButton maleRadioButton;
                private System.Windows.Forms.RadioButton femaleRadioButton;
                private System.Windows.Forms.CheckBox marriedCheckbox;
                private System.Windows.Forms.Label expensesLabel;
                private System.Windows.Forms.TextBox expensesInput;
                private System.Windows.Forms.Label birthDateLabel;
                private System.Windows.Forms.DateTimePicker dateOfBirth;
                private System.Windows.Forms.Label ageLabel;
                private System.Windows.Forms.TextBox ageInput;
                private System.Windows.Forms.TextBox copayWithheldPercenatgeInput;
                private System.Windows.Forms.Label copayPercentLabel;
                private System.Windows.Forms.Label addressLabel;
                private System.Windows.Forms.TextBox txtStreet;
                private System.Windows.Forms.TextBox cityInput;
                private System.Windows.Forms.TextBox pincodeInput;
                private System.Windows.Forms.Label copayDollerLabel;
                private System.Windows.Forms.TextBox copayWithheld;
                private System.Windows.Forms.TextBox insuranceInput;
                private System.Windows.Forms.Label insuranceLabel;
                private System.Windows.Forms.Label homePhoneLabel;
                private System.Windows.Forms.TextBox homePhoneInput;
                private System.Windows.Forms.TextBox mobilePhoneInput;
                private System.Windows.Forms.Label mobilePhoneLabel;
                private System.Windows.Forms.RadioButton redOutPatient;
                private System.Windows.Forms.RadioButton residentRadioButton;
                private System.Windows.Forms.TextBox conFirstNameInput;
                private System.Windows.Forms.Label conFirstNameLabel;
                private System.Windows.Forms.Label conLastNameLabel;
                private System.Windows.Forms.TextBox contactLastName;
                private System.Windows.Forms.TextBox contactPhone;
                private System.Windows.Forms.Label conPhoneLabel;
                private System.Windows.Forms.Label hospitalNameLabel;
                private System.Windows.Forms.TextBox hospitalInput;
                private System.Windows.Forms.TextBox hospitalPhoneInput;
                private System.Windows.Forms.Label hospitalPhoneLabel;
                private System.Windows.Forms.Button addButton;
                private System.Windows.Forms.Button updateButton;
                private System.Windows.Forms.Button deleteButton;
                private System.Windows.Forms.Button clearButton;
                private System.Windows.Forms.ListBox patientListBox;
                private System.Windows.Forms.GroupBox genderGroupBox;
                private System.Windows.Forms.GroupBox patientTypeGroupBox;
                private System.Windows.Forms.ComboBox comState;
                private System.Windows.Forms.MenuStrip menuStrip1;
                private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
                private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
                private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
                private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
                private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
                private System.Windows.Forms.ToolStripMenuItem pageSetupStripMenuItem;
                private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
                private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
                private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
                private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
                private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
                private System.Windows.Forms.ToolStripMenuItem abroutPayrollSystemToolStripMenuItem;
        }
}

