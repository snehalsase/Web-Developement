﻿// Employee abstract base class.

using System;

[Serializable]
public abstract class Patient
{
        // private instance variable for storing first name
        private string firstNameValue;

        // private instance variable for storing last name
        private string lastNameValue;



        // private instance variable for storing birth date
        private DateTime birthDateValue;

        // parameter-less constructor
        public Patient()
        {
        }

        // constructor
        public Patient(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, string conFirstName, string conLastName, PhoneNumber conPhone, string hospitalName, PhoneNumber hospitalPhone, decimal expenses)
        {
                this.FirstName = first;
                this.LastName = last;
                this.Married = married;
                this.Gender = gender;
                this.BirthDate = birthDate;
                this.HomeAddress = homeAddress;
                this.HomePhone = homePhone;
                this.CellPhone = cellPhone;
                this.Expenses = expenses;
        } // end Patient constructor

        // property to get and set employee's first name
        public string FirstName
        {
                get
                {
                        return Util.Capitalize(firstNameValue);
                } // end get
                set
                {
                        value = value.Trim().ToUpper();
                        if (value.Length < 1)
                                throw new ApplicationException("First name is empty!");
                        // check for letters
                        foreach (char c in value)
                                if (c < 'A' || c > 'Z')
                                        throw new ApplicationException("First name must consist of letters only!");
                        firstNameValue = value;
                } // end set
        } // end property FirstName

        // property to get and set patient's last name
        public string LastName
        {
                get
                {
                        return Util.Capitalize(lastNameValue);
                } // end get
                set
                {
                        value = value.Trim().ToUpper();
                        if (value.Length < 1)
                                throw new ApplicationException("Last name is empty!");
                        // check for letters
                        foreach (char c in value)
                                if (c < 'A' || c > 'Z')
                                        throw new ApplicationException("Last name must consist of letters only!");
                        lastNameValue = value;
                } // end set
        } // end property LastName

        // read-only property to get patient's name
        public string Name
        {
                get
                {
                        return LastName + ", " + FirstName;
                } // end get
        } // end property Name

        // property to get and set whether patient is married
        public bool Married { get; set; }

        // read-only property to get patient's marital status
        public string MaritalStatus
        {
                get
                {
                        if (Married)
                                return "married";
                        else
                                return "single";
                } // end get
        } // end property Name

        // property to get and set whether patient is male
        public bool IsMale { get; set; }

        // property to get and set whether patient is female
        public bool IsFemale
        {
                get
                {
                        return !IsMale;
                } // end get
                set
                {
                        IsMale = !value;
                } // end set
        } // end property IsFemale

        // property to get and set patient's gender
        public string Gender
        {
                get
                {
                        if (IsMale)
                                return "Male";
                        else
                                return "Female";
                } // end get
                set
                {
                        value = value.ToUpper();
                        if (value == "MALE" || value == "M")
                                IsMale = true;
                        else if (value == "FEMALE" || value == "F")
                                IsMale = false;
                        else
                                throw new ApplicationException("Gender should be Male or Female!");
                } // end set
        } // end property Gender

        // read-only property to get patient's title
        public string Title
        {
                get
                {
                        if (IsMale)
                                return "Mr.";
                        else
                                return "Ms.";
                } // end get
        } // end property Title

        // read-only property to get patient's title and name
        public string TitleName
        {
                get
                {
                        return Title + " " + Name;
                } // end get
        } // end property TitleName

        // property to get and set patient's birth date
        public DateTime BirthDate
        {
                get
                {
                        return birthDateValue;
                } // end get
                set
                {
                        if (value > DateTime.Now)
                        {
                                throw new ApplicationException("Patient birth date must be prior to today!");
                        }
                        birthDateValue = value;
                } // end set
        } // end property BirthDate

        // read-only property to get patient's age
        public byte Age
        {
                get
                {
                        // Get the birth date value for the current year.

                        DateTime thisYearBirthDate = new DateTime(DateTime.Now.Year, BirthDate.Month, BirthDate.Day);

                        // Calculate and return the age based on if the birth date has occurred this year or not.

                        if (thisYearBirthDate <= DateTime.Now)
                        {
                                return (byte)(DateTime.Now.Year - BirthDate.Year);
                        }
                        else
                        {
                                return (byte)(DateTime.Now.Year - BirthDate.Year - 1);
                        }
                }
        }

        // property to get and set patient's home address
        public Address HomeAddress { get; set; }

        // property to get and set patient's home phone
        public PhoneNumber HomePhone { get; set; }

        // property to get and set patient's cell phone
        public PhoneNumber CellPhone { get; set; }

        // returns string representation of Patient object
        public override string ToString()
        {
                var displayStr = "";
                if (Category == "Out")
                {
                        displayStr = TitleName + "\t"
                          + Category + "\t"
                + MaritalStatus + "\t"
              + "Age :" + Age + "\t" + "Expenses :" + Expenses + "\t" + "Copay : " + CopayWithheld + "\t" + "Coverage:" + Insurance

             + "\t" + HomeAddress + "\t" + "Contact Address :" + ContactAddress;
                }
                else
                {
                        displayStr = TitleName + "\t"
                          + Category + "\t"
                + MaritalStatus + "\t"
              + "Age :" + Age + "\t" + "Expenses :" + Expenses + "\t" + "Copay : " + CopayWithheld + "\t" + "Coverage:" + Insurance

             + "\t" + HomeAddress + "\t" + "Hospital Address:" + HospitalAddress;

                }
                return displayStr;
        } // end method ToString

        // virtual readonly property for Category, will be overridden by derived classes
        public virtual string Category
        {
                get
                {
                        return "Patient";
                }
        } // no implementation here

        public decimal Insurance
        {
                get

                {
                        return  Expenses - CopayWithheld;

                }
        }

        public abstract string ContactFirstName { get; set; }

        public abstract string ContactLastName { get; set; }

        // property to get and set contact's cell phone
        public abstract PhoneNumber ContactPhone { get; set; }

        public abstract string HospitalName { get; set; }

        // property to get and set hospital's cell phone
        public abstract PhoneNumber HospitalPhone { get; set; }

        public decimal Expenses
        {
                get; set;
        } // no implementation here


        // abstract readonly property for CopayWithholdingPercentage, will be overridden by derived classes
        public abstract double CopayWithholdingPercentage
        {
                get;
        } // no implementation here

        // read-only property to get patient's CopayWithheld
        public abstract decimal CopayWithheld
        {
                get;
               
        }

        public string ContactAddress
        {
                get {
                        return ContactFirstName + " " + ContactLastName + " " + ContactPhone;
                }
        }

        public string HospitalAddress
        {
                get
                {
                        return HospitalName + " " + HospitalPhone;
                }
        }
}
