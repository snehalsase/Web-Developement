﻿using System;

[Serializable]
public class OutPatient : Patient
{

        // private instance variable for storing first name
        private string conFirstNameValue;

        // private instance variable for storing last name
        private string conLastNameValue;

        // parameter-less constructor
        public OutPatient()
            : base()
        {
        }

        // constructor
        public OutPatient(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, string conFirstName, string conLastName, PhoneNumber conPhone, string hospitalName, PhoneNumber hospitalPhone, decimal expenses)
           : base(first, last, married, gender, birthDate, homeAddress, homePhone, cellPhone, conFirstName, conLastName, conPhone, hospitalName, hospitalPhone, expenses)
        {
                this.conFirstNameValue = conFirstName;
                this.conLastNameValue = conLastName;
                this.ContactPhone = conPhone;

        } // end OuterPatient constructor


        // override Patient's abstract property Category 
        public override string Category
        {
                get
                {
                        return "Out";
                }
        } // end property Category

        // override Patient's abstract property TaxWithholdingPercentage 
        public override double CopayWithholdingPercentage
        {
                get
                {
                        return 2.5;
                }
        } // end property CopayWithholdingPercentage

        public override decimal CopayWithheld
        {
                get
                {
                        return Expenses * (decimal)CopayWithholdingPercentage / 100;
                }
        }

        public override string ContactFirstName
        {
                get
                {
                        return Util.Capitalize(conFirstNameValue);
                } // end get
                set
                {
                        value = value.Trim().ToUpper();
                        if (value.Length < 1)
                                throw new ApplicationException(" Contact First name is empty!");
                        // check for letters
                        foreach (char c in value)
                                if (c < 'A' || c > 'Z')
                                        throw new ApplicationException("First name must consist of letters only!");
                        conFirstNameValue = value;
                } // end set
        }

        public override string ContactLastName
        {
                get
                {
                        return Util.Capitalize(conLastNameValue);
                } // end get
                set
                {
                        value = value.Trim().ToUpper();
                        if (value.Length < 1)
                                throw new ApplicationException(" Contact Last name is empty!");
                        // check for letters
                        foreach (char c in value)
                                if (c < 'A' || c > 'Z')
                                        throw new ApplicationException("Contact Last must consist of letters only!");
                        conLastNameValue = value;
                } // end set
        }

        public override PhoneNumber ContactPhone { get; set; }
       

        public override PhoneNumber HospitalPhone { get; set; }

        public override string HospitalName { get; set; }
}

