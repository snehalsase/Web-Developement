﻿
using System;

[Serializable]
public class ResidentPatient : Patient
{

        // parameter-less constructor
        // private instance variable for storing first name
        private string hospitalName;
        public ResidentPatient()
            : base()
        {
        }

        // constructor
        public ResidentPatient(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, string conFirstName, string conLastName, PhoneNumber conPhone, string hospitalName, PhoneNumber hospitalPhone, decimal expenses)
           : base(first, last, married, gender, birthDate, homeAddress, homePhone, cellPhone, conFirstName, conLastName, conPhone, hospitalName, hospitalPhone, expenses)
        {
                this.hospitalName = hospitalName;
                this.HospitalPhone = hospitalPhone;
        } // end ResidentPatient constructor


        // override Patient's abstract property Category 
        public override string Category
        {
                get
                {
                        return "Resident";
                }
        } // end property Category

        // override Patient's abstract property TaxWithholdingPercentage 
        public override  double CopayWithholdingPercentage
        {
                get
                {
                        return 5;
                }
        } // end property TaxWithholdingPercentage

        public override decimal CopayWithheld
        {
                get
                {
                        return Expenses * (decimal)CopayWithholdingPercentage / 100;
                }
        }

        public override string HospitalName
        {
                get
                {
                        return Util.Capitalize(hospitalName);
                } // end get
                set
                {
                        value = value.Trim().ToUpper();
                        if (value.Length < 1)
                                throw new ApplicationException("Hospital name is empty!");
                        hospitalName = value;
                } // end set
        }

        public override PhoneNumber HospitalPhone { get; set; }

        public override string ContactFirstName { set; get; }

        public override string ContactLastName { set; get; }

        public override PhoneNumber ContactPhone { get; set; }
}