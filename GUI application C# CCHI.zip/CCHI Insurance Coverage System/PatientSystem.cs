﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CCHISystem
{
        public partial class PatientSystem : Form
        {
                public PatientSystem()
                {
                        InitializeComponent();

                        patientListBox.HorizontalScrollbar = true;
                      
                        foreach (string state in Address.StateNames)
                                comState.Items.Add(state);

                       
                        clear();
                }

                private void label3_Click(object sender, EventArgs e)
                {

                }

                private void addButton_Click(object sender, EventArgs e)
                {
                        add();
                }

                private void updateButton_Click(object sender, EventArgs e)
                {
                       
                        if (patientListBox.SelectedItems.Count == 0)
                        {
                                return;
                        }

                        if (MessageBox.Show("Are you sure you want to update the following employee?\n" +
                            (Patient)patientListBox.SelectedItem,
                           "Patient System", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                                return;

                        if (add())
                                patientListBox.Items.Remove(patientListBox.SelectedItem);
                }

                private void deleteButton_Click(object sender, EventArgs e)
                {
                        
                        if (patientListBox.SelectedItems.Count == 0)
                        {
                                return;
                        }

                        if (MessageBox.Show("Are you sure you want to delete the following patient?\n" +
                            (Patient)patientListBox.SelectedItem,
                           "Patient System", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                                patientListBox.Items.Remove(patientListBox.SelectedItem);
                }

                private void clearButton_Click(object sender, EventArgs e)
                {
                        clear();
                }

                private void comState_SelectedIndexChanged(object sender, EventArgs e)
                {

                }

                // clear all fields
                private void clear()
                {
                        firstNameInput.Text = "";
                        lastNameInput.Text = "";
                        maleRadioButton.Checked = true;
                        marriedCheckbox.Checked = false;
                        dateOfBirth.Text = DateTime.Now.ToShortDateString();
                        ageInput.Text = "";
                        txtStreet.Text = "";
                        cityInput.Text = "Milwaukee";
                        comState.Text = "WISCONSIN";
                        pincodeInput.Text = "53201";
                        homePhoneInput.Text = "(414)";
                        mobilePhoneInput.Text = "(414)";
                        redOutPatient.Checked = true;
                        if (redOutPatient.Checked)
                        {
                                conFirstNameInput.Text = "";
                                contactPhone.Text = "";
                                contactLastName.Text = "";
                        }
                        else if (!redOutPatient.Checked)
                        {
                                hospitalInput.Text = "";
                                hospitalPhoneInput.Text = "";

                        }
                        expensesInput.Text = "";
                        patientTypeInput.Text = "";
                        copayWithheldPercenatgeInput.Text = "";
                        copayWithheld.Text = "";
                        insuranceInput.Text = "";
                }

                // add a new employee
                private bool add()
                {
                        Patient patient;
                        if (redOutPatient.Checked)
                                patient = new OutPatient();
                        else
                                patient = new ResidentPatient();
                        if (getInputs(patient) == true)
                        {
                                patientListBox.Items.Add(patient);
                                displayPatient(patient);
                                return true;
                        }
                        return false;
                }

                // get input fields of patient
                private bool getInputs(Patient patient)
                {
                        try
                        {
                                patient.FirstName = firstNameInput.Text;
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                firstNameInput.Focus();
                                return false;
                        }

                        try
                        {
                                patient.LastName = lastNameInput.Text;
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                lastNameInput.Focus();
                                return false;
                        }

                        try
                        {
                                patient.HomePhone = new PhoneNumber(homePhoneInput.Text);
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                homePhoneInput.Focus();
                                return false;
                        }

                        try
                        {
                                patient.CellPhone = new PhoneNumber(mobilePhoneInput.Text);
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                mobilePhoneInput.Focus();
                                return false;
                        }

                        patient.IsMale = maleRadioButton.Checked;

                        patient.Married = marriedCheckbox.Checked;

                        try
                        {
                                patient.BirthDate = dateOfBirth.Value;
                                ageInput.Text = patient.Age.ToString();
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                dateOfBirth.Focus();
                                return false;
                        }

                        try
                        {
                                patient.HomeAddress = new Address(txtStreet.Text, cityInput.Text, comState.Text, pincodeInput.Text);
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                comState.Focus();
                                return false;
                        }

                        if(redOutPatient.Checked)
                        {
                                try
                                {
                                        patient.ContactFirstName = conFirstNameInput.Text;
                                }
                                catch (Exception ex)
                                {
                                        MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        conFirstNameInput.Focus();
                                        return false;
                                }

                                try
                                {
                                        patient.ContactLastName = contactLastName.Text;
                                }
                                catch (Exception ex)
                                {
                                        MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        contactLastName.Focus();
                                        return false;
                                }

                                try
                                {
                                        patient.ContactPhone = new PhoneNumber(contactPhone.Text);
                                }
                                catch (Exception ex)
                                {
                                        MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        contactPhone.Focus();
                                        return false;
                                }
                        }
                        else
                        {
                                try
                                {
                                        patient.HospitalPhone = new PhoneNumber(hospitalPhoneInput.Text);
                                }
                                catch (Exception ex)
                                {
                                        MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        hospitalPhoneInput.Focus();
                                        return false;
                                }

                                try
                                {
                                        patient.HospitalName = hospitalInput.Text;
                                }
                                catch (Exception ex)
                                {
                                        MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                        hospitalInput.Focus();
                                        return false;
                                }
                        }

                        try
                        {
                                patient.Expenses = decimal.Parse(expensesInput.Text);
                        }
                        catch (Exception ex)
                        {
                                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                expensesInput.Focus();
                                return false;
                        }
                        return true;
                }

                // display employee
                private void displayPatient(Patient patient)
                {
                        firstNameInput.Text = patient.FirstName;
                        lastNameInput.Text = patient.LastName;
                        homePhoneInput.Text = patient.HomePhone.ToString();
                        mobilePhoneInput.Text = patient.CellPhone.ToString();
                        marriedCheckbox.Checked = patient.Married;
                        maleRadioButton.Checked = patient.IsMale;
                        femaleRadioButton.Checked = patient.IsFemale;
                        dateOfBirth.Text = patient.BirthDate.ToShortDateString();
                        ageInput.Text = patient.Age.ToString();
                        txtStreet.Text = patient.HomeAddress.Street;
                        cityInput.Text = patient.HomeAddress.City;
                        comState.Text = patient.HomeAddress.State;
                        pincodeInput.Text = patient.HomeAddress.Zip;
                        patientTypeInput.Text = patient.Category;
                        expensesInput.Text = patient.Expenses.ToString();
                        copayWithheldPercenatgeInput.Text = patient.CopayWithholdingPercentage.ToString();

                        copayWithheld.Text = "$" + patient.CopayWithheld.ToString();
                        insuranceInput.Text = "$" + patient.Insurance.ToString();

                        if(patient.Category == "Out")
                        {
                                redOutPatient.Checked = true;
                                conFirstNameInput.Text = patient.ContactFirstName;
                                contactLastName.Text = patient.ContactLastName;
                                contactPhone.Text = patient.ContactPhone.ToString();
                        }
                        else if(patient.Category == "Resident")
                        {
                                hospitalInput.Text = patient.HospitalName;
                                hospitalPhoneInput.Text = patient.HospitalPhone.ToString();
                                residentRadioButton.Checked = true;
                        }
                       
                }

                private void lstPatient_SelectedIndexChanged(object sender, EventArgs e)
                {
                        
                        if (patientListBox.SelectedItems.Count == 0)
                        {
                                return;
                        }

                        Patient patient = (Patient)patientListBox.SelectedItem;
                        clear();
                        displayPatient(patient);
                }

                private void openToolStripMenuItem_Click(object sender, EventArgs e)
                {
                        
                        BinaryFormatter reader = new BinaryFormatter();
                        FileStream input = null; 


                        DialogResult result;
                        string fileName; 

                      
                        using (OpenFileDialog fileChooser = new OpenFileDialog())
                        {
                                result = fileChooser.ShowDialog();
                                fileName = fileChooser.FileName; 
                        }


                        
                        if (result == DialogResult.Cancel)
                                return;

                        
                        if (fileName == "" || fileName == null)
                        {
                                MessageBox.Show("Invalid File Name", "Error",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                        }

                        try
                        {
                               
                                input = new FileStream(
                                   fileName, FileMode.Open, FileAccess.Read);

                                
                                patientListBox.Items.Clear();
                                Patient patient = (Patient)reader.Deserialize(input);
                                while (patient != null)
                                {
                                        patientListBox.Items.Add(patient);
                                        patient = (Patient)reader.Deserialize(input);
                                }
                        }
                        catch
                        {
                        }
                        finally
                        {
                                if (input != null)
                                        input.Close();
                        }

                }

                private void printToolStripMenuItem_Click(object sender, EventArgs e)
                {
                        MessageBox.Show("The printing function is still under construction!",
                "Patient System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                private void abroutPayrollSystemToolStripMenuItem_Click(object sender, EventArgs e)
                {
                        MessageBox.Show("Patient Information System V1.0, xyz",
             "About Patient System", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                private void exitToolStripMenuItem_Click(object sender, EventArgs e)
                {
                        Close();
                }

                private void PatientSystemForm_FormClosing(object sender, FormClosingEventArgs e)
                {
                        if (MessageBox.Show("Are you sure you want to exit the system?",
               "Patient System", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                                e.Cancel = true;
                }

                private void pageSetupStripMenuItem_Click(object sender, EventArgs e)
                {
                        MessageBox.Show("The page setup function is still under construction!",
               "Patient System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
                {
                        MessageBox.Show("The print preview function is still under construction!",
              "Patient System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                private void saveToolStripMenuItem_Click(object sender, EventArgs e)
                {
                        if (patientListBox.Items.Count == 0)
                                return;

                        
                        BinaryFormatter formatter = new BinaryFormatter();
                        FileStream output = null; 

                        DialogResult result;
                        string fileName; 

                        
                        using (SaveFileDialog fileChooser = new SaveFileDialog())
                        {
                                fileChooser.CheckFileExists = false; 
                                result = fileChooser.ShowDialog();
                                fileName = fileChooser.FileName; 
                        }

                       
                        if (result == DialogResult.Cancel)
                                return;

                       
                        if (fileName == "" || fileName == null)
                        {
                                MessageBox.Show("Invlaid File Name", "Error",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                        }

                       
                        try
                        {
                                
                                output = new FileStream(fileName,
                                   FileMode.OpenOrCreate, FileAccess.Write);
                               
                                foreach (Patient item in patientListBox.Items)
                                {
                                        formatter.Serialize(output, item);
                                }
                        } 
                        catch (IOException)
                        {
                               
                                MessageBox.Show("Error opening file", "Error",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                        } 
                        catch (SerializationException)
                        {
                                MessageBox.Show("Error writing to file", "Error",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                        } 
                        finally
                        {
                                if (output != null)
                                        output.Close();
                        }
                }

                private void redOutPatient_CheckedChanged(object sender, EventArgs e)
                {

                }

                private void residentRadioButton_CheckedChanged(object sender, EventArgs e)
                {

                }

        private void PatientSystem_Load(object sender, EventArgs e)
        {

        }
    }
}
